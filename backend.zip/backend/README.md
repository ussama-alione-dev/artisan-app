# Artisan Backend — Express + MongoDB (Mongoose)

Backend API pour une plateforme de mise en relation clients / artisans (plomberie,
électricité, etc.), avec chat en temps réel via Socket.io.

## Structure du projet

```
backend/
├── .env                      # Variables d'environnement (à ne pas commit)
├── .env.example               # Modèle des variables requises
├── package.json
├── src/
│   ├── server.js               # Point d'entrée (Express + Socket.io)
│   ├── socket.js                # Handlers Socket.io (chat temps réel)
│   ├── seed.js                  # Script de seed (données de démo)
│   ├── config/
│   │   └── db.js                 # Connexion MongoDB (Mongoose)
│   ├── models/                  # Schémas Mongoose
│   │   ├── User.js
│   │   ├── Artisan.js
│   │   ├── Demande.js
│   │   └── Message.js
│   ├── controllers/              # Logique métier
│   │   ├── authController.js
│   │   ├── artisanController.js
│   │   ├── demandeController.js
│   │   └── messageController.js
│   ├── routes/                   # Définition des routes Express
│   │   ├── auth.js
│   │   ├── artisans.js
│   │   ├── demandes.js
│   │   └── messages.js
│   ├── middleware/
│   │   ├── auth.js                # requireAuth / requireRole (JWT)
│   │   └── errorHandler.js         # 404 + gestion centralisée des erreurs
│   └── utils/
│       ├── jwt.js                  # sign / verify JWT
│       └── catchAsync.js           # wrapper pour les routes async
└── tests/
    ├── verify.js                   # Test bout-en-bout de l'API REST
    └── verify-chat.js              # Test bout-en-bout du chat Socket.io
```

## Installation

```bash
cd backend
npm install
```

## Configuration

Copie `.env.example` vers `.env` et adapte les valeurs :

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/artisan_db
JWT_SECRET=change-this-secret-key
JWT_EXPIRES_IN=7d
CLIENT_URL=http://localhost:3000
```

- **MONGO_URI** : locale (`mongodb://127.0.0.1:27017/artisan_db`) ou
  [MongoDB Atlas](https://www.mongodb.com/atlas) (`mongodb+srv://...`).
- Assure-toi que MongoDB tourne localement, ou utilise un cluster Atlas.

## Lancer le serveur

```bash
# Peupler la base avec des données de démo (utilisateurs + artisans)
npm run seed

# Démarrage en développement (avec rechargement auto)
npm run dev

# Démarrage en production
npm start
```

Comptes de démo créés par `npm run seed` (mot de passe : `password123`) :
- Client : `client@demo.fr`
- Artisans : `plombier@demo.fr`, `elec@demo.fr`, `serrurier@demo.fr`,
  `clim@demo.fr`, `peintre@demo.fr`, `menuisier@demo.fr`

## Tests de vérification

Avec le serveur lancé et la base peuplée :

```bash
node tests/verify.js         # REST API
node tests/verify-chat.js    # Socket.io chat
```

## API

| Méthode | Route                     | Auth              | Description                          |
|---------|----------------------------|-------------------|---------------------------------------|
| GET     | `/api/health`               | non                | Vérifie que le serveur répond          |
| POST    | `/api/auth/register`        | non                | Créer un compte (client ou artisan)    |
| POST    | `/api/auth/login`           | non                | Connexion, retourne un JWT             |
| GET     | `/api/auth/me`               | oui                | Profil de l'utilisateur connecté       |
| GET     | `/api/artisans`              | non                | Liste/recherche des artisans           |
| GET     | `/api/artisans/:userId`      | non                | Détail d'un artisan                    |
| PUT     | `/api/artisans/profile`      | oui (artisan)       | Créer/mettre à jour son profil artisan |
| POST    | `/api/demandes`               | oui (client)         | Créer une demande d'intervention        |
| GET     | `/api/demandes`               | oui                | Lister ses demandes                     |
| PATCH   | `/api/demandes/:id`           | oui (artisan)        | Mettre à jour le statut d'une demande   |
| GET     | `/api/messages/:roomId`       | oui                | Historique des messages d'une room      |

## Chat temps réel (Socket.io)

Événements côté client :
- `join_room(roomId)` → reçoit `message_history`
- `send_message({ roomId, senderId, senderName, text })` → diffuse `new_message`
- `typing({ roomId, senderName })` → diffuse `user_typing`
- `stop_typing({ roomId })` → diffuse `user_stop_typing`
