// models/Demande.js — Job request from a client to an artisan
const mongoose = require("mongoose");

const demandeSchema = new mongoose.Schema(
  {
    client: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    artisan: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    description: {
      type: String,
      required: [true, "Description is required"],
      trim: true,
    },
    address: {
      type: String,
      trim: true,
    },
    urgency: {
      type: String,
      enum: ["low", "normal", "high"],
      default: "normal",
    },
    desiredDate: {
      type: Date,
    },
    status: {
      type: String,
      enum: ["pending", "accepted", "refused", "done"],
      default: "pending",
    },
  },
  { timestamps: true }
);

demandeSchema.index({ client: 1 });
demandeSchema.index({ artisan: 1 });

module.exports = mongoose.model("Demande", demandeSchema);
