// models/Artisan.js — Artisan profile, linked 1-to-1 with a User (role=artisan)
const mongoose = require("mongoose");

const artisanSchema = new mongoose.Schema(
    {
        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
            unique: true,
        },
        specialty: {
            type: String,
            trim: true,
        },
        city: {
            type: String,
            trim: true,
        },
        phone: {
            type: String,
            trim: true,
        },
        description: {
            type: String,
            trim: true,
        },
        hourlyRate: {
            type: Number,
            min: 0,
        },
        available: {
            type: Boolean,
            default: true,
        },
    },
    { timestamps: true },
);

artisanSchema.index({ specialty: 1, city: 1 });

module.exports = mongoose.model("Artisan", artisanSchema);
