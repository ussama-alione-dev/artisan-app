// config/db.js — MongoDB connection via Mongoose
const mongoose = require("mongoose");

async function connectDB() {
    const uri = process.env.MONGO_URI;

    if (!uri) {
        throw new Error("MONGO_URI is not defined in .env");
    }

    mongoose.set("strictQuery", true);

    try {
        const conn = await mongoose.connect(uri);
        console.log(
            `✅ MongoDB connected: ${conn.connection.host}/${conn.connection.name}`,
        );
    } catch (err) {
        console.error("❌ MongoDB connection error:", err.message);
        process.exit(1);
    }

    mongoose.connection.on("disconnected", () => {
        console.warn("⚠️  MongoDB disconnected");
    });
}

module.exports = connectDB;
