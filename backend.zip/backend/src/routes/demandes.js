// routes/demandes.js
const express = require("express");
const {
  createDemande,
  getMyDemandes,
  updateDemandeStatus,
} = require("../controllers/demandeController");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();

router.post("/", requireAuth, requireRole("client"), createDemande);
router.get("/", requireAuth, getMyDemandes);
router.patch("/:id", requireAuth, requireRole("artisan"), updateDemandeStatus);

module.exports = router;
