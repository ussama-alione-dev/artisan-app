// routes/messages.js
const express = require("express");
const { getRoomMessages } = require("../controllers/messageController");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

router.get("/:roomId", requireAuth, getRoomMessages);

module.exports = router;
