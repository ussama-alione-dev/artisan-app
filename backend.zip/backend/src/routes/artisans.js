// routes/artisans.js
const express = require("express");
const {
  getAllArtisans,
  getArtisanByUserId,
  upsertOwnProfile,
} = require("../controllers/artisanController");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();

router.get("/", getAllArtisans);
router.put("/profile", requireAuth, requireRole("artisan"), upsertOwnProfile);
router.get("/:userId", getArtisanByUserId);

module.exports = router;
