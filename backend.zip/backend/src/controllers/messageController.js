// controllers/messageController.js — Chat message history
const Message = require("../models/Message");
const catchAsync = require("../utils/catchAsync");

// GET /api/messages/:roomId
exports.getRoomMessages = catchAsync(async (req, res) => {
    const messages = await Message.find({ roomId: req.params.roomId }).sort({
        createdAt: 1,
    });
    res.json(messages);
});
