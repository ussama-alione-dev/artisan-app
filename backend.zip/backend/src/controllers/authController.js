// controllers/authController.js — Register & Login
const bcrypt = require("bcryptjs");
const User = require("../models/User");
const { signToken } = require("../utils/jwt");
const catchAsync = require("../utils/catchAsync");

// POST /api/auth/register
exports.register = catchAsync(async (req, res) => {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password || !role) {
        return res.status(400).json({ error: "All fields are required" });
    }

    if (!["client", "artisan"].includes(role)) {
        return res
            .status(400)
            .json({ error: "Role must be 'client' or 'artisan'" });
    }

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) {
        return res.status(400).json({ error: "Email already in use" });
    }

    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, password: hashed, role });

    const token = signToken({ id: user._id, role: user.role });
    res.status(201).json({ token, user: user.toSafeObject() });
});

// POST /api/auth/login
exports.login = catchAsync(async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res
            .status(400)
            .json({ error: "Email and password are required" });
    }

    const user = await User.findOne({ email: email.toLowerCase() }).select(
        "+password",
    );
    if (!user) return res.status(400).json({ error: "Invalid credentials" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ error: "Invalid credentials" });

    const token = signToken({ id: user._id, role: user.role });
    res.json({ token, user: user.toSafeObject() });
});

// GET /api/auth/me
exports.me = catchAsync(async (req, res) => {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json(user.toSafeObject());
});
