// controllers/artisanController.js — Artisan profile CRUD + search
const Artisan = require("../models/Artisan");
const User = require("../models/User");
const catchAsync = require("../utils/catchAsync");

// GET /api/artisans?specialty=&city=&available=
exports.getAllArtisans = catchAsync(async (req, res) => {
    const { specialty, city, available } = req.query;
    const filter = {};

    if (specialty) filter.specialty = new RegExp(`^${specialty}$`, "i");
    if (city) filter.city = new RegExp(city, "i");
    if (available === "true") filter.available = true;

    const artisans = await Artisan.find(filter).populate("user", "name email");

    const results = artisans.map((a) => ({
        id: a._id,
        userId: a.user?._id,
        name: a.user?.name || "Unknown",
        email: a.user?.email,
        specialty: a.specialty,
        city: a.city,
        phone: a.phone,
        description: a.description,
        hourlyRate: a.hourlyRate,
        available: a.available,
        createdAt: a.createdAt,
    }));

    res.json(results);
});

// GET /api/artisans/:userId — fetch by the underlying user id
exports.getArtisanByUserId = catchAsync(async (req, res) => {
    const artisan = await Artisan.findOne({ user: req.params.userId }).populate(
        "user",
        "name email",
    );
    if (!artisan) return res.status(404).json({ error: "Artisan not found" });

    res.json({
        id: artisan._id,
        userId: artisan.user?._id,
        name: artisan.user?.name || "Unknown",
        email: artisan.user?.email,
        specialty: artisan.specialty,
        city: artisan.city,
        phone: artisan.phone,
        description: artisan.description,
        hourlyRate: artisan.hourlyRate,
        available: artisan.available,
        createdAt: artisan.createdAt,
    });
});

// PUT /api/artisans/profile — create or update own artisan profile
exports.upsertOwnProfile = catchAsync(async (req, res) => {
    const { specialty, city, phone, description, hourlyRate, available } =
        req.body;

    const updated = await Artisan.findOneAndUpdate(
        { user: req.user.id },
        { specialty, city, phone, description, hourlyRate, available },
        {
            new: true,
            upsert: true,
            runValidators: true,
            setDefaultsOnInsert: true,
        },
    ).populate("user", "name email");

    res.json({
        id: updated._id,
        userId: updated.user?._id,
        name: updated.user?.name,
        email: updated.user?.email,
        specialty: updated.specialty,
        city: updated.city,
        phone: updated.phone,
        description: updated.description,
        hourlyRate: updated.hourlyRate,
        available: updated.available,
    });
});
