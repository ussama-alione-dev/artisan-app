// controllers/demandeController.js — Job request (demande) CRUD
const Demande = require("../models/Demande");
const catchAsync = require("../utils/catchAsync");

const ALLOWED_STATUSES = ["pending", "accepted", "refused", "done"];

// POST /api/demandes — client creates a job request
exports.createDemande = catchAsync(async (req, res) => {
    const { artisanId, description, address, urgency, desiredDate } = req.body;

    if (!artisanId || !description) {
        return res
            .status(400)
            .json({ error: "artisanId and description are required" });
    }

    const demande = await Demande.create({
        client: req.user.id,
        artisan: artisanId,
        description,
        address,
        urgency: urgency || "normal",
        desiredDate,
    });

    res.status(201).json(demande);
});

// GET /api/demandes — get current user's demandes (as client or artisan)
exports.getMyDemandes = catchAsync(async (req, res) => {
    const filter =
        req.user.role === "client"
            ? { client: req.user.id }
            : { artisan: req.user.id };

    const demandes = await Demande.find(filter)
        .populate("client", "name")
        .populate("artisan", "name")
        .sort({ createdAt: -1 });

    const enriched = demandes.map((d) => ({
        id: d._id,
        clientId: d.client?._id,
        clientName: d.client?.name || "Unknown",
        artisanId: d.artisan?._id,
        artisanName: d.artisan?.name || "Unknown",
        description: d.description,
        address: d.address,
        urgency: d.urgency,
        desiredDate: d.desiredDate,
        status: d.status,
        createdAt: d.createdAt,
    }));

    res.json(enriched);
});

// PATCH /api/demandes/:id — artisan updates status
exports.updateDemandeStatus = catchAsync(async (req, res) => {
    const demande = await Demande.findById(req.params.id);
    if (!demande) return res.status(404).json({ error: "Demande not found" });

    if (
        req.user.role !== "artisan" ||
        demande.artisan.toString() !== req.user.id
    ) {
        return res.status(403).json({ error: "Not authorized" });
    }

    const { status } = req.body;
    if (!ALLOWED_STATUSES.includes(status)) {
        return res
            .status(400)
            .json({
                error: `Status must be one of: ${ALLOWED_STATUSES.join(", ")}`,
            });
    }

    demande.status = status;
    await demande.save();

    res.json(demande);
});
