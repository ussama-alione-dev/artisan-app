// utils/catchAsync.js — Wraps async route handlers, forwards errors to errorHandler
module.exports = function catchAsync(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};
