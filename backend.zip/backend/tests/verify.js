// tests/verify.js — Basic end-to-end smoke test against a running server
// Requires the server to be running (npm run dev) with MongoDB connected and seeded.
// Usage: node tests/verify.js

const BASE_URL = process.env.BASE_URL || "http://127.0.0.1:5000/api";

async function run() {
  console.log("🧪 Running end-to-end verification...");

  // 1. Health check
  console.log("1. GET /health");
  const health = await fetch(`${BASE_URL}/health`).then((r) => r.json());
  console.log("   ✅ status:", health.status);

  // 2. Client login
  console.log("2. POST /auth/login (client@demo.fr)");
  const clientLogin = await fetch(`${BASE_URL}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: "client@demo.fr", password: "password123" }),
  }).then((r) => r.json());
  if (!clientLogin.token) throw new Error("Client login failed: " + JSON.stringify(clientLogin));
  console.log("   ✅ logged in as:", clientLogin.user.name, "| role:", clientLogin.user.role);
  const clientToken = clientLogin.token;

  // 3. Artisan login
  console.log("3. POST /auth/login (plombier@demo.fr)");
  const artisanLogin = await fetch(`${BASE_URL}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: "plombier@demo.fr", password: "password123" }),
  }).then((r) => r.json());
  if (!artisanLogin.token) throw new Error("Artisan login failed: " + JSON.stringify(artisanLogin));
  console.log("   ✅ logged in as:", artisanLogin.user.name);
  const artisanToken = artisanLogin.token;
  const artisanUserId = artisanLogin.user.id;

  // 4. Search artisans
  console.log("4. GET /artisans?specialty=Plomberie&city=Paris");
  const search = await fetch(`${BASE_URL}/artisans?specialty=Plomberie&city=Paris`).then((r) =>
    r.json()
  );
  console.log(`   ✅ found ${search.length} artisan(s)`);

  // 5. Artisan profile update
  console.log("5. PUT /artisans/profile (as artisan)");
  const profileUpdate = await fetch(`${BASE_URL}/artisans/profile`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${artisanToken}`,
    },
    body: JSON.stringify({ hourlyRate: 72, available: true }),
  }).then((r) => r.json());
  console.log("   ✅ updated hourlyRate:", profileUpdate.hourlyRate);

  // 6. Client creates a demande
  console.log("6. POST /demandes (as client)");
  const demande = await fetch(`${BASE_URL}/demandes`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${clientToken}`,
    },
    body: JSON.stringify({
      artisanId: artisanUserId,
      description: "Fuite sous l'évier de la cuisine",
      address: "12 rue de Paris",
      urgency: "high",
    }),
  }).then((r) => r.json());
  if (!demande._id && !demande.id) throw new Error("Demande creation failed: " + JSON.stringify(demande));
  console.log("   ✅ demande created:", demande._id || demande.id);
  const demandeId = demande._id || demande.id;

  // 7. Artisan accepts the demande
  console.log("7. PATCH /demandes/:id (as artisan)");
  const patched = await fetch(`${BASE_URL}/demandes/${demandeId}`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${artisanToken}`,
    },
    body: JSON.stringify({ status: "accepted" }),
  }).then((r) => r.json());
  console.log("   ✅ demande status:", patched.status);

  // 8. Client lists their demandes
  console.log("8. GET /demandes (as client)");
  const myDemandes = await fetch(`${BASE_URL}/demandes`, {
    headers: { Authorization: `Bearer ${clientToken}` },
  }).then((r) => r.json());
  console.log(`   ✅ client has ${myDemandes.length} demande(s)`);

  console.log("\n🎉 All checks passed!");
}

run().catch((err) => {
  console.error("❌ Verification failed:", err.message);
  process.exit(1);
});
