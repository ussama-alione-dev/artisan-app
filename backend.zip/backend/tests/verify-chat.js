// tests/verify-chat.js — Smoke test for the Socket.io chat feature
// Requires the server to be running (npm run dev) with MongoDB connected and seeded.
// Usage: node tests/verify-chat.js

const { io } = require("socket.io-client");

const BASE_URL = process.env.SOCKET_URL || "http://127.0.0.1:5000";
const ROOM_ID = "test-room-" + Date.now();

async function run() {
  console.log("🧪 Running chat verification...");

  const socketA = io(BASE_URL, { transports: ["websocket"] });
  const socketB = io(BASE_URL, { transports: ["websocket"] });

  await Promise.all([
    new Promise((resolve) => socketA.on("connect", resolve)),
    new Promise((resolve) => socketB.on("connect", resolve)),
  ]);
  console.log("   ✅ both sockets connected");

  socketA.emit("join_room", ROOM_ID);
  socketB.emit("join_room", ROOM_ID);

  const received = new Promise((resolve) => {
    socketB.on("new_message", (msg) => resolve(msg));
  });

  socketA.emit("send_message", {
    roomId: ROOM_ID,
    senderId: "000000000000000000000000",
    senderName: "Tester A",
    text: "Salut, ça te va demain matin ?",
  });

  const msg = await received;
  console.log("   ✅ message received by socketB:", msg.text);

  socketA.disconnect();
  socketB.disconnect();
  console.log("\n🎉 Chat verification passed!");
  process.exit(0);
}

run().catch((err) => {
  console.error("❌ Chat verification failed:", err.message);
  process.exit(1);
});
